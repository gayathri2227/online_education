package com.exam.exception;

public class ResourceNotFoundException extends RuntimeException {
	 
    public ResourceNotFoundException(String message) {
 
        super(message);
 
    }

}
